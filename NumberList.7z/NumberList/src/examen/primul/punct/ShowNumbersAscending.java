package examen.primul.punct;

import java.util.ArrayList;
import java.util.Collections;

public class ShowNumbersAscending implements IShowNumbersStrategy{

	public void showNumbers(ArrayList<Integer> numbers) {
		Collections.sort(numbers);
		for (int nr : numbers) {
			System.out.println(nr);
		}
	}
}
