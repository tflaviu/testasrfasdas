package examen.primul.punct;

public class DescendingEvenOdd {

}
