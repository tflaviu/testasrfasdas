package examen.primul.punct;

import java.util.ArrayList;

public class NumbersList {
	private ArrayList<Integer> numbers = new ArrayList<Integer>();
	private IShowNumbersStrategy showNumbersStrategy;
	
	public NumbersList (ArrayList<Integer> numbers, final IShowNumbersStrategy showNumbersStrategy) {
		this.numbers = numbers;
		this.showNumbersStrategy = showNumbersStrategy;
	}
	
	public void showNumbers() {
		this.showNumbersStrategy.showNumbers(this.numbers);
	}

}
