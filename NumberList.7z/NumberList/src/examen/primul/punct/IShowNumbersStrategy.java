package examen.primul.punct;

import java.util.ArrayList;

public interface IShowNumbersStrategy {
	public void showNumbers(ArrayList<Integer> numbers);
}
