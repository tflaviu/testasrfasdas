package examen.primul.punct;

import java.util.ArrayList;
import java.util.Arrays;

public class Main {
	public static void main(String [] args) {
		ArrayList<Integer> nrs = new ArrayList<>(Arrays.asList(1,2,3, 10, 5));
		
		IShowNumbersStrategy ascending = new ShowNumbersAscending();
		IShowNumbersStrategy descending = new ShowNumbersDescending();

		NumbersList numbers = new NumbersList(nrs, ascending);
		NumbersList numbersDesc = new NumbersList(nrs, descending);
		numbers.showNumbers();
		numbersDesc.showNumbers();
	}
	
}
